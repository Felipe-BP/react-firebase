import React, { Component } from 'react';
import './dashboard.css'
import Title from '../title/title'
import Perfil from '../perfil/perfil-component'
import Button from '../button/Button'
import Habilidades from '../skills/habilidades';
import Blog from '../blog/blog'
import Work from '../works/work'
import Infos from '../infos/infos'
import Contact from '../contact/contact'
import Footer from '../footer/footer'
import fire from '../config/fire'


class Dashboard extends Component {

  constructor(props){
    super(props);
    this.state = {
      user: {},
      nome : '',
      sobrenome : '',
      interesses : [],
      idiomas : [],
      formacao : [],
      atividades : [],
      skills : [],
      trabalho1 : '',
      trabalho2 : '',
      trabalho3 : '',
      biografia : '',
      profissao : '',
      linkGitH : '',
      linkInsta : '',
      linkFace : '',
      linkLinke : ''
    }
    this.lerDados = this.lerDados.bind(this);
  }

  componentDidMount(){
    this.authListener();
    this.lerDados();
  }

  authListener(){
    fire.auth().onAuthStateChanged((user) => {
      if(user){
        this.setState({ user });
        console.log(this.state.user);
      } else {
        this.setState({ user : null });
        console.log(this.state);
        window.location.href = "/";
      }
    });
  }

  lerDados(){
    fire.database().ref('users' + this.state.user.uid).child('user').once('value').then(snap => {
      this.setState({
        [this.state.nome] : snap.val().name,
        [this.state.sobrenome] : snap.val().lastName,
        [this.state.interesses] : snap.val().interesses,
        [this.state.idiomas] : snap.val().idiomas,
        [this.state.formacao] : snap.val().formacao,
        [this.state.atividades] : snap.val().atividades,
        [this.state.skills] : snap.val().skills,
        [this.state.trabalho1] : snap.val().trabalho1,
        [this.state.trabalho2] : snap.val().trabalho2,
        [this.state.trabalho3] : snap.val().trabalho3,
        [this.state.biografia] : snap.val().biografia,
        [this.state.profissao] : snap.val().profissao,
        [this.state.linkGitH] : snap.val().linkGitH,
        [this.state.linkInsta] : snap.val().linkInsta,
        [this.state.linkFace] : snap.val().linkFace,
        [this.state.linkLinke] : snap.val().linkLinke
      })
    })
    console.log(this.state);
  }

  render() {
    return (<div>
              <section className="perfil" id="perfil">
                <div className="title">
                  <Title value="Perfil" color="false" />
                </div>
                <Perfil />
                <div className="title">
                  <Button value="Download Currículo" content="./assets/Currículo.pdf" color="false"/>
                </div>
              </section>
              <section id="habilidades">
                  <div>
                    <Title value="Skills" color="true" />
                  </div>
                  <div>
                    <h3 className="p">Estas são algumas de minhas habilidades!</h3>
                    <Habilidades />
                  </div>
              </section>
              <section id="blog">
                <div className="title">
                  <Title value="Blog" color="false" />
                </div>
                <Blog />
              </section>
              <section id="trabalhos">
                <div className="title">
                  <Title value="Trabalhos" color="true" />
                </div>
                <h3 className="p">Estes são alguns de meus trabalhos</h3>
                <div className="title">
                  <Work />
                </div>
              </section>
              <section id="infos">
                <div className="title">
                  <Title value="Mais Informações" color="false" />
                </div>
                <h3>Mais algumas informações sobre mim</h3>
                <Infos />
                <div>
                  <a target="_blank" rel="noopener noreferrer" href="https://github.com/Felipe-BP">
                    <img src="./assets/github-icon.png" alt="icone repositório github"/>
                  </a>
                  <p>Link para o meu perfil do GitHub</p>
                </div>
              </section>
              <section id="contato">
                <div className="title">
                  <Title value="Contato" color="true" />
                </div>
                <Contact />
                <div className="title">
                  <h5 className="p">Link para as minhas redes sociais!</h5>
                  <ul id="redes-sociais">
                    <li>
                      <a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/felipe.bueno.56679"><img src="./assets/facebook-icon.png" alt="icone facebook"/></a>
                    </li>
                    <li>
                      <a target="_blank" rel="noopener noreferrer" href="https://www.instagram.com/felipe.bueno01/?hl=pt-br"><img src="./assets/instagram-icon.png" alt="icone instagram"/></a>
                    </li>
                    <li>
                      <a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/in/felipe-bueno-de-paula-85898815b/"><img src="./assets/linkedin-icon.png" alt="icone linkedin"/></a>
                    </li>
                  </ul>
                </div>
              </section>
              <Footer name="Felipe Bueno Web Developer" email="gvv.fel@gmail.com" number="+55 (43) 996209896" />
            </div>
            );
  }
}

export default Dashboard;